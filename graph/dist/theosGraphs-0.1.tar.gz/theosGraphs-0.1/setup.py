from setuptools import setup

setup(name='theosGraphs',
        version='0.1',
        description='A Graph package for discrete math',
        url='http://github.com/tlincke125/Data-Structures',
        author='Theo Lincke',
        author_email='tlincke@protonmail.com',
        license='MIT',
        packages=['theosGraphs'],
        zip_safe=False)
